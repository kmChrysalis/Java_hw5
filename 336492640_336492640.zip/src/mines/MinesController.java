package mines;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import java.util.function.UnaryOperator;

public class MinesController {
    public static int height, width, mines; //variable for saving size, and mines count
    public static GridPane grid; //grind for field
    public static Mines game; //our game :)
    public static Btn[][] buttons; //buttons array to be placed into grid
    @FXML
    private Button restart_button;
    @FXML
    private TextField setWidth;
    @FXML
    private TextField setHeight;
    @FXML
    private TextField setMines;
    @FXML
    private StackPane pane;
    @FXML
    public static Label Finish;

    @FXML
    void initialize() {
        DropShadow ds = new DropShadow(); //create effect of shadow
        ds.setOffsetY(10.0f); //move it a bit by Y
        ds.setOffsetX(10.0f); //move it by X
        Finish.setStyle("-fx-text-fill: #A3001A;" + //set color and bold characters
                "-fx-font-weight: bold;");
        Finish.setEffect(ds); //set shadow for Finish label
        pane.setMaxSize(1770,1070);

        UnaryOperator<TextFormatter.Change> intFilter = change -> //unary operator to exclude invalid input
                change.getControlNewText().matches("\\d{0,9}") ? change : null;

        setHeight.setTextFormatter(new TextFormatter<String>(intFilter));
        setWidth.setTextFormatter(new TextFormatter<String>(intFilter));
        setMines.setTextFormatter(new TextFormatter<String>(intFilter));

        restart_button.setOnAction(event -> { //create listener for restart button
            /*get size of field, but I add some bounds, in case it won't get out of screen with resolution 1920x1080 */
            height = Integer.parseInt(setHeight.getCharacters().toString()) % 22;
            width = Integer.parseInt(setWidth.getCharacters().toString()) % 37;
            /* amount of mines are bounded by field, i.e. 10x10 = 100, so <=100 mines can be placed */
            mines = Integer.parseInt(setMines.getCharacters().toString()) % (height*width + 1);

            if (grid != null) { //if grid already has been created
                grid.getChildren().clear(); //clear this grid
                Finish.setVisible(false); //make finish label invisible
            }

            if (height > 0 && width > 0 && mines > 0) { //if variables are bigger then 0, we can go forward
                game = new Mines(height, width, mines); //create new game
                buttons = new Btn[height][width]; //create array of buttons
                grid = new GridPane(); //create new grid pane
                grid.setAlignment(Pos.CENTER); //set it position on middle
                grid.setPrefSize(930, 700); //preferable size
                grid.setMaxSize(1770, 1070); //maximum size

                for (int i = 0; i < height; i++) { //creating new buttons
                    for (int j = 0; j < width; j++) {
                        buttons[i][j] = new Btn(new Button(game.get(i, j)), i, j);
                        grid.add(buttons[i][j].getB(), j, i); //add this button to grid
                    }
                }
                pane.getChildren().add(grid); //add our grid to StackPane
            }
        });
    }
}