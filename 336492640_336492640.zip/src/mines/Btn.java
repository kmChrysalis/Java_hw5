package mines;

import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;

import static mines.MinesController.*;

public class Btn { //my button class
    private Button b;

    public Button getB() {
        return b;
    }

    private int x, y; //coordinates
    private boolean flag = false; //flag toggle

    public Btn(Button b, int x, int y) { //constructor
        this.b = b;
        this.x = x;
        this.y = y;
        this.b.setMinSize(48, 48); //minimal size of button
        this.b.setPrefSize(54, 54); //preferable size
        this.b.setMaxSize(54, 54); //maximum size
        /* get some style */
        this.b.setStyle("-fx-background-image: url('/resources/closed.jpg');" +
                "-fx-text-fill: Black;" +
                "-fx-border-color: Black;" +
                "-fx-border-width: 1;" +
                "-fx-font-size: 24;" +
                "-fx-font-weight: bold ");
        /* and add mouse listener */
        this.b.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.SECONDARY) { //check if right button was pressed
                flag = game.toggleFlag(this.x, this.y); //toggle flag
                if (flag) {
                    this.b.setText(""); //set text, and stylish
                    this.b.setStyle("-fx-background-image: url('/resources/flag.jpg');" +
                            "-fx-text-fill: Black;" +
                            "-fx-border-color: Black;" +
                            "-fx-border-width: 1;" +
                            "-fx-font-size: 24;" +
                            "-fx-font-weight: bold;");
                } else {
                    this.b.setText(".");
                    this.b.setStyle("-fx-background-image: url('/resources/closed.jpg');" +
                            "-fx-text-fill: Black;" +
                            "-fx-border-color: Black;" +
                            "-fx-border-width: 1;" +
                            "-fx-font-size: 24;" +
                            "-fx-font-weight: bold;");
                }
            } else { //if left button was pressed
                if (!game.open(this.x, this.y)) { //trying to open, if false, we lost
                    shower("YOU DIED"); //using external function to open all cells, after set new bomb pic to one we pressed
                    this.b.setStyle("-fx-background-image: url('/resources/bomb_active.jpg');" +
                            "-fx-text-fill: Black;" +
                            "-fx-border-color: Black;" +
                            "-fx-border-width: 1;" +
                            "-fx-font-size: 24;" +
                            "-fx-font-weight: bold ");
                } else if (game.isDone()) { //check if you won
                    shower("YOU WON");
                } else {
                    this.b.setOnMouseClicked(null); //deactivate button we press and add styles
                    this.b.setStyle("-fx-background-image: url('/resources/opened.jpg');" +
                            "-fx-text-fill: Black;" +
                            "-fx-border-color: Black;" +
                            "-fx-border-width: 1;" +
                            "-fx-font-size: 24;" +
                            "-fx-font-weight: bold;");
                    this.b.setText(game.get(this.x, this.y)); //set number for button
                    checks(); //check neighbours
                }
            }
        });
    }

    private void shower(String str) {
        Finish.setVisible(true); //showing message
        Finish.setText(str); //set string as label
        game.setShowAll(true); //toggle showAll flag
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                buttons[i][j].b.setOnMouseClicked(null); //deactivate button
                String key = game.get(i, j); //get a key
                if (key.equals("X")) { //if this cell is mine, set mine image
                    buttons[i][j].b.setStyle("-fx-background-image: url('/resources/bomb_not_active.jpg');" +
                            "-fx-text-fill: Black;" +
                            "-fx-border-color: Black;" +
                            "-fx-border-width: 1;" +
                            "-fx-font-size: 24;" +
                            "-fx-font-weight: bold ");
                } else { //if this cell not mine, it's just an opened one
                    buttons[i][j].b.setStyle("-fx-background-image: url('/resources/opened.jpg');" +
                            "-fx-text-fill: Black;" +
                            "-fx-border-color: Black;" +
                            "-fx-border-width: 1;" +
                            "-fx-font-size: 24;" +
                            "-fx-font-weight: bold;");
                    buttons[i][j].b.setText(key); //probably with some text, or without, depends on key
                }
            }
        }
    }

    private void checks() {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                if (game.isOpened(i, j)) { //if this cell is opened, set image of opened
                    buttons[i][j].b.setStyle("-fx-background-image: url('/resources/opened.jpg');" +
                            "-fx-text-fill: Black;" +
                            "-fx-border-color: Black;" +
                            "-fx-border-width: 1;" +
                            "-fx-font-size: 24;" +
                            "-fx-font-weight: bold; ");
                    buttons[i][j].b.setText(game.get(i, j)); //set text, if it has
                    buttons[i][j].b.setOnMouseClicked(null); //deactivate listener
                }
            }
        }
    }
}
